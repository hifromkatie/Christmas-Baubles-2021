#include <stdio.h>
#include <stdlib.h>
#include "pico/stdlib.h"
#include <string.h>

int ledPins[] = {2, 3, 4, 5, 6, 7, 8, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22};


#define LEDCOUNT 20
#define MAX_LED_COUNT 5


int ledsOn[MAX_LED_COUNT];

int currentLed = 0;

int mode = 1; 
//mode: 0=all off, 1= all on, 2 = flashing, 3 = random

int speed = 250;


void leds_on (int newLed){
	if (ledsOn[MAX_LED_COUNT-1] != 99){
		int lastLed = ledsOn[MAX_LED_COUNT-1];
		gpio_put(ledPins[lastLed], 1);
	}
	
	for (int x=MAX_LED_COUNT-1; x>0; x--){
			ledsOn[x]=ledsOn[x-1];
	}
	gpio_put(ledPins[newLed], 0);
	ledsOn[0]=newLed;
}

void all_on(void){
	for (int i=0; i<LEDCOUNT; i++){
				currentLed=i;
				leds_on(currentLed);
		}
}

void all_off(void){
	for (int i=0; i<LEDCOUNT; i++){
				gpio_put(ledPins[i], 1);
		}
}

void flashing(void){
	for (int t=0; t<10000; t++){
		all_on();
	}
	all_off();
	sleep_ms(250);
}

void random_led(int delayTime){
	int randVal = rand() % LEDCOUNT;
	leds_on(randVal);
	sleep_ms(delayTime);
}





void setup(){
	stdio_init_all();	
	for (int currentLed = 0; currentLed< LEDCOUNT; currentLed++){
		gpio_init(ledPins[currentLed]);
		gpio_set_dir(ledPins[currentLed], GPIO_OUT);
		gpio_put(ledPins[currentLed], 1);
	}
	
	for (int i = 0; i<MAX_LED_COUNT; i++){
		ledsOn[i] = 99;
	}
	
	gpio_init(0);
	gpio_set_dir(0, GPIO_IN);
	gpio_pull_up(0);
	gpio_init(1);
	gpio_set_dir(1, GPIO_IN);
	gpio_pull_up(1);
	
}

int main(){
	setup();
	
	
	
	while (1){
		if (!gpio_get(0)){
			if (!gpio_get(1)){
				mode = 0;
			}else{
				mode = 1;
			}
		}else{
			if (!gpio_get(1)){
				mode = 2;
			}else{
				mode = 3;
			}
		}
	
		switch (mode){
			case 0:
				all_off();
				break;
			case 1:
				all_on();
				break;
			case 2:
				flashing();
				break;
			case 3:
				random_led(speed);
				break;
			
			default:
				all_off();
		}
	}
}
